﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        Double peso, altura, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void Label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void MskbxPeso_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(mskbxPeso.Text, out peso))
            {
                MessageBox.Show("Peso inválido");
                mskbxPeso.Focus();
            }
            if(peso>=300)
            {
                MessageBox.Show("Digite um número menor que 300");
                mskbxPeso.Focus();
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
            mskbxResultado.Clear();
            altura = 0;
            peso = 0;
            imc = 0;
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            imc = peso / (Math.Pow(altura, 2));

            MessageBox.Show(string.Format("{0} {1} {2} ?", imc, peso, altura));
             
            if (imc < 18.5)
            {
                mskbxResultado.Text = imc.ToString();
                MessageBox.Show("Magreza");
            }
            else
                if (imc < 25)
            {
                mskbxResultado.Text = imc.ToString();
                MessageBox.Show("Normal");
            }
                else
                    if (imc < 30)
            {
                mskbxResultado.Text = imc.ToString();
                MessageBox.Show("Sobrepeso");
            }
                    else
                        if (imc < 40)
                         {
                                mskbxResultado.Text = imc.ToString();
                                MessageBox.Show("Obesidade");
                        }
                        else
                            if(imc>=40)
            {
                mskbxResultado.Text = imc.ToString();
                MessageBox.Show("Obesidade Grave");
            }
        }

        private void TxtAltura_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(mskbxAltura.Text, out altura))
            {
                MessageBox.Show("Altura inválida");
                mskbxAltura.Focus();
            }
            if(altura>=2.5)
            {
                MessageBox.Show("Digite um valor menor que 2.5");
                mskbxAltura.Focus();
            }
        }
    }
}
