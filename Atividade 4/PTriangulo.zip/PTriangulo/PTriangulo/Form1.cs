﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double ladoa;
        double ladob;
        double ladoc;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtbxA.Clear();
            txtbxB.Clear();
            txtbxC.Clear();
            ladoa = 0;
            ladob = 0;
            ladoc = 0;
            txtbxA.Focus();
        }

        private void TxtbxA_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtbxA, "");

            if(!Double.TryParse(txtbxA.Text, out ladoa) || ladoa <= 0)
            {
                errorProvider1.SetError(txtbxA, "Valor de A inválido");
            }
        }

        private void TxtbxB_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtbxB, "");

            if (!Double.TryParse(txtbxB.Text, out ladob)|| ladoa<=0)
            {
                errorProvider2.SetError(txtbxB, "Valor de B inválido");
            }
        }

        private void TxtbxC_Validated(object sender, EventArgs e)
        {
            errorProvider3.SetError(txtbxC, "");

            if (!Double.TryParse(txtbxC.Text, out ladoc)||ladoa<=0)
            {
                errorProvider3.SetError(txtbxC, "Valor de C inválido");
            }
        }

        private void BtnAnalisar_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbxA.Text, out ladoa)||
                !double.TryParse(txtbxB.Text, out ladob)|| !double.TryParse(txtbxC.Text, out ladoc))
                MessageBox.Show("Valores devem ser numéricos");



            if ((Math.Abs(ladob-ladoc)<ladoa)&&(ladoa<ladob+ladoc)&&(Math.Abs(ladoa-ladoc)<ladob)&&
                    (ladob<ladoa+ladoc)&&(Math.Abs(ladob-ladoa)<ladoc)&&(ladoc<ladoa+ladob))
            {
                MessageBox.Show("Pode ser um triângulo");
                if((ladoa==ladob)&&(ladob==ladoc)&&(ladoa==ladoc))
                    MessageBox.Show($"Os valores {ladoa}, {ladob} e {ladoc} formam um triângulo equilátero");
                if((ladoa==ladob)||(ladoa==ladoc)||(ladob==ladoc))
                    MessageBox.Show($"Os valores {ladoa}, {ladob} e {ladoc} formam um triângulo isóceles");
                else
                    MessageBox.Show($"Os valores {ladoa}, {ladob} e {ladoc} formam um triângulo escaleno");
            }
            else
                MessageBox.Show($"Os valores {ladoa}, {ladob} e {ladoc} não formam um triângulo");
        }
    }
}
